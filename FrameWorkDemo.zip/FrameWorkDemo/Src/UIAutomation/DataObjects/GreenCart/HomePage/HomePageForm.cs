﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIAutomation.DataObjects.GreenCart.HomePage
{
    public class HomePageForm
    {
        public string Quantity { get; set; }
    }
}
