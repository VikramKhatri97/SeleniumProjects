﻿namespace UIAutomation.Enum
{
    public enum BrowserName
    {
        FireFox = 1,
        Chrome = 2,
        Safari = 3,
        None = 4
    }
}