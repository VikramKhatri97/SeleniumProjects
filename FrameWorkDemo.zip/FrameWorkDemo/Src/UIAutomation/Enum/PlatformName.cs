﻿namespace UIAutomation.Enum
{
    public enum PlatformName
    {
        Web = 1,
        Android = 2,
        Ios = 3,
        AndroidApp = 4,
        IosApp = 5
    }
}