﻿namespace UIAutomation.Enum
{
    public enum CalenderPicker
    {
        FlatPickerCalender = 1,
        RangeCalenderMonthView = 2,
        RangeCalenderYearView = 3
    }
}