﻿namespace UIAutomation.Enum.Recruiters
{
    public enum UserType
    {
        Traveler = 1,
        Guest = 2
    }
}
