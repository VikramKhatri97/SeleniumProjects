﻿namespace UIAutomation.Enum.Recruiters
{
    public enum RoleType
    {
        Client = 1,
        Other = 2,
        Traveler = 3
    }
}