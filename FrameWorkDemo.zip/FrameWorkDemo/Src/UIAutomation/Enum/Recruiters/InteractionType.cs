﻿namespace UIAutomation.Enum.Recruiters
{
    public enum InteractionType
    {
        JustOnce = 1,
        FewTimes = 2,
        SeveralTimes = 3,
        ManyTimes = 4
    }
}
